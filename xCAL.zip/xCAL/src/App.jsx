import React from 'react';
import './App.css';
import ReactScheduler from "./scheduler/ReactScheduler.jsx";

const App = () => {
  return (
    <ReactScheduler />
  );
}

export default App;
